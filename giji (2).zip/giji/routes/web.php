<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// 【ユーザー】ログイン画面
Route::get('login', 'Auth\User\LoginController@showLoginForm')->name('login');
// 【ユーザー】ログイン機能
Route::post('login', 'Auth\User\LoginController@login');
// 【ユーザー】新規登録画面
Route::get('register', 'Auth\User\RegisterController@showRegistrationForm')->name('register');
// 【ユーザー】新規登録機能
Route::post('register', 'Auth\User\RegisterController@register');
// 【ユーザー】ログアウト機能
Route::post('logout', 'Auth\User\LoginController@logout')->name('logout');

// 【ユーザー】トップページ
Route::get('/', 'ProductController@home')->name('home');
// 【ユーザー】商品一覧画面
Route::get('products', 'ProductController@index')->name('user.product.index');
//  【ユーザー】検索機能
Route::post('search','ProductController@search')->name('search');

// 【管理者】ルートプレフィックスグループ
Route::prefix('admin')->group(function () {
    // 【管理者】ログイン画面
    Route::get('login', 'Auth\Admin\LoginController@showLoginForm')->name('admin.login');
    // 【管理者】ログイン機能
    Route::post('login', 'Auth\Admin\LoginController@login');
    // 【管理者】新規登録画面
    Route::get('register', 'Auth\Admin\RegisterController@showRegistrationForm')->name('admin.register');
    // 【管理者】新規登録機能
    Route::post('register', 'Auth\Admin\RegisterController@register');
    // 【管理者】ログアウト機能
    Route::post('logout', 'Auth\Admin\LoginController@logout')->name('admin.logout');
    });

// 【ユーザー】認証判定用ルートグループ
Route::name('user.')
    ->middleware('auth')
    ->group(function () {
        // 【ユーザー】コーデ一覧画面
        Route::get('scenes', 'SceneController@index')->name('scene.index');
        // 【ユーザー】コーデ詳細画面
        Route::get('scene/{scene}', 'SceneController@show')->name('scene.show');
        // 【ユーザー】コーデ作成画面
        Route::get('scene/create', 'SceneController@create')->name('scene.create');
        // 【ユーザー】コーデ作成機能
        Route::post('scene/store', 'SceneController@store')->name('scene.store');
        // 【ユーザー】コーデ編集画面
        Route::get('scene/edit/{scene}', 'SceneController@edit')->name('scene.edit');
        // 【ユーザー】コーデ編集機能
        Route::put('scene/update/{scene}', 'SceneController@update')->name('scene.update');

        // 【ユーザー】お気に入り一覧画面
        Route::get('products/favorites', 'FavoriteController@index')->name('product.favorites');
        // 【ユーザー】お気に入り機能
        Route::post('products/favorite/{product}', 'FavoriteController@favorite')->name('product.favorite');
        // 【ユーザー】お気に入り機能解除
        Route::delete('products/unfavorite/{product}', 'FavoriteController@unfavorite')->name('product.unfavorite');

        // 【ユーザー】プロフィール
        Route::get('profile', 'UserController@profile')->name('profile');
        // 【ユーザー】プロフィール編集画面
        Route::get('profile/edit', 'UserController@edit')->name('profile.edit');
        // 【ユーザー】プロフィール編集機能
        Route::put('profile/update', 'UserController@update')->name('profile.update');

        // 【ユーザー】カート一覧画面
        Route::get('cart', 'UserController@cartIndex')->name('cart.index');
        // 【ユーザー】カート追加機能
        Route::post('products/cart/{product}', 'ProductController@cart')->name('product.cart');
        // 【ユーザー】カート削除機能
        Route::delete('products/uncart/{product}', 'ProductController@uncart')->name('product.uncart');

        // 【ユーザー】購入画面
        Route::post('purchase/{product}', 'ProductController@purchase')->name('purchase');
        // 【ユーザー】カート個数選択機能
        Route::post('purchase/{product}/piecies', 'ProductController@piecies')->name('product.piecies');
        // 【ユーザー】購入確認画面
        Route::get('purchase/{product}/confirm', 'ProductController@purchaseConfirm')->name('purchase.confirm');
        // 【ユーザー】購入履歴画面
        Route::get('purchased', 'UserController@purchased')->name('purchased');
    });

// 【ユーザー】商品詳細画面
Route::get('products/{product}', 'ProductController@show')->name('user.product.show');

// 【管理者】認証判定用ルートグループ
Route::prefix('admin')
    ->name('admin.')
    ->middleware('auth:admin')
    ->group(function () {
        // 【管理者】ホーム画面
        Route::get('home', 'ProductController@adminHome')->name('home');

        // 【管理者】商品検索機能
        Route::get('product/search', 'ProductController@adminSearch')->name('product.search');
        // 【管理者】商品一覧画面
        Route::get('products', 'ProductController@adminIndex')->name('product.index');
        // 【管理者】商品登録画面
        Route::get('product/create', 'ProductController@adminCreate')->name('product.create');
        // 【管理者】商品登録機能
        Route::post('product/store', 'ProductController@adminStore')->name('product.store');
        // 【管理者】商品編集画面
        Route::get('product/edit/{product}', 'ProductController@adminEdit')->name('product.edit');
        // 【管理者】商品編集機能
        Route::put('product/update/{product}', 'ProductController@adminUpdate')->name('product.update');
        // 【管理者】商品削除機能
        Route::delete('product/delete/{product}', 'ProductController@adminDestroy')->name('product.destroy');
        // 【管理者】商品編集画面
        Route::get('product/edit/{product}', 'ProductController@adminEdit')->name('product.edit');

        // 【管理者】コーデ一覧画面
        Route::get('scenes', 'SceneController@adminIndex')->name('scene.index');
        // 【管理者】コーデ作成画面
        Route::get('scene/create', 'SceneController@adminCreate')->name('scene.create');
        // 【管理者】コーデ作成機能
        Route::post('scene/store', 'SceneController@adminStore')->name('scene.store');
        // 【管理者】コーデ編集画面
        Route::get('scene/edit/{scene}', 'SceneController@adminEdit')->name('scene.edit');
        // 【管理者】コーデ編集機能
        Route::put('scene/update/{scene}', 'SceneController@adminUpdate')->name('scene.update');
    });
