@extends('admin.layouts.app')

@section('admin.content')

<h2>-登録済み商品一覧-</h2>
@if($products->count())
    @foreach($products as $product)
    <div>
        @if($product->productImages()->exists())
            <div>
                <img src="{{ asset('images/' . $product->productImages->first()->image) }}" name="myBigImage">
            </div>
            <ul>
                @foreach($product->productImages as $productImage)
                    <li>
                        <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $product->product }}の画像{{ $loop->index + 1 }}">
                    </li>
                @endforeach
            </ul>
        @else
            <p>画像はありません</p>
        @endif
        <p>商品名：{{ $product->product }}</p>
        <p>金額：{{ $product->price }}円</p>
        <p>size：
            @foreach($product->details as $detail)
                {{ $detail->size }}
            @endforeach
        </p>
        <form onsubmit="return confirm('カートから削除してよろしいですか？')" action="{{ route('admin.product.destroy', $product->id) }}" method="POST">
        @csrf
        @method('delete')
            <button type="submit">
                <img src="{{ asset('img/9CCB62AC-3D0D-4B7C-BC78-904AAAFFE52B.png') }}" alt="カートから削除の画像">
            </button>
        </form>
        <a href="{{ route('admin.product.edit', $product->id) }}">商品を編集する</a>
    </div>
    @endforeach
@else
    <p>「{{ $keyword }}」に一致する商品が見つかりませんでした。</p>
@endif

@endsection