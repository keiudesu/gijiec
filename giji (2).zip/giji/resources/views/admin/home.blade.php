@extends('admin.layouts.app')

@section('admin.content')
<div><a href="{{ route('admin.product.create') }}">商品を新規登録する</a></div>
<div><a href="{{ route('admin.scene.index') }}">シーン別コーデを登録・編集する</a></div>
<h1>登録済み商品一覧</h1>
@foreach($products as $product)
@if($product->productImages->count())
  @foreach($product->productImages as $productImage)
  <div><img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $product->product }}の画像{{ $loop->index + 1 }}"></div>
  @endforeach
@else
  <p>画像はありません</p>
@endif
  <p>{{ $product->number }}</p>
  <p>{{ $product->product }}</p>
  <p>{{ $product->price }}</p>
  @foreach($product->details as $detail)
  <p>サイズ：{{ $detail->size }}</p>
  <p>カラー：{{ $detail->color }}</p>
  @endforeach
  <button type="submit">
    <img src="{{ asset('img/9CCB62AC-3D0D-4B7C-BC78-904AAAFFE52B.png') }}" alt="商品削除の画像">
  </button>
  <div><a href="{{ route('admin.product.edit', $product->id) }}">商品情報を編集する</a></div>
@endforeach
<div><a href="{{ route('admin.product.index') }}">さらに表示</a></div>
@endsection
