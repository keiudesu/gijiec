<footer>
  <div class="footer">
    <small>&copy;2022 proj_22_0709</small>
  </div>
</footer>
