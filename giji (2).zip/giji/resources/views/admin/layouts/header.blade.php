<header>
  <div class="header">
    <div class="header-left">
      <div class="menu-trigger">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <ul class="humburger">
          <li><a href="{{ route('admin.home') }}">Top</a></li>
          @auth
          <li>
            <form action="{{ route('admin.logout') }}" method="POST">
              @csrf
              <button type="submit" class="logout-btn">ログアウト</button>
            </form>
          </li>
          @endauth
      </ul>
      <div class="search">
        <img src="{{ asset('img/47EE5B58-65B0-40D8-AAB6-83BA1B731413.jpg') }}" class="search-img">
        <form action="{{ route('admin.product.search') }}" method="GET">
          @csrf
          <input type="text" class="search-bar" name="admin_search">
        </form>
      </div>
    </div>
    <div>
      <img src="{{ asset('img/IMG_0083.jpg') }}" class="header-title">
    </div>
    <div class="header-right">
      @auth
        <p class="header-username">{{ Auth::user()->name }}さん</p>
      @endauth
      <div class="header-mypage">
        <img src="{{ asset('img/658FDF52-6E8A-4C48-893E-8C54EE7A0778.png') }}" class="header-img">
      </div>
    </div>
  </div>
</header>
