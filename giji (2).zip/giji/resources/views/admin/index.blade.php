@extends('admin.layouts.app')

@section('admin.content')
<h1>ITEM LIST</h1>
<p>商品一覧画面</p>
    @foreach($products as $product)
        <a href="{{ route('admin.product.edit', $product->id) }}">
        <div>
            @if($product->productImages->count())
                @foreach($product->productImages as $productImage)
                    <div><img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $product->product }}の画像{{ $loop->index + 1 }}"></div>
                @endforeach
            @else
            <p>画像はありません</p>
            @endif
            <h4>{{ $product->product }}</h4>
            <p>¥{{ $product->price }}</p>
        </div>
        </a>
    @endforeach
{{ $products->links() }}
@endsection
