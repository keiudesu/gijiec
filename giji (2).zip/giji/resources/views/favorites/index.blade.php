@extends('layouts.app')

@section('content')
<h1>-お気に入りリスト-</h1>
    @if($user->favorites()->exists())
    @foreach($user->favorites as $favorite)
        @if($favorite->product->productImages->count())
            @foreach($favorite->product->productImages as $productImage)
                <div>
                  <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $productImage->product->product }}の画像{{ $loop->index+1 }}">
                </div>
            @endforeach
        @else
            <p>画像はありません</p>
        @endif
        <p>商品名:{{ $favorite->product->product }}</p>
        <p>値段:{{ $favorite->product->price }}</p>
        <a href="">
            <button>
                <img src="{{ asset('images/delete') }}" alt="お気に入りから削除">
            </button>
        </a>
        <form action="{{ route('user.product.cart', $favorite->product->id) }}" method="post">
        @csrf
            <button type="submit">
                <img src="{{ asset('images/favorite.png') }}" alt="お気に入りボタンの画像">
            </button>
        </form>
    @endforeach
    @else
        <p>まだお気に入りした商品はありません。</p>
    @endif
@endsection
