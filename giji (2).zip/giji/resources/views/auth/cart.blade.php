@extends('layouts.app')

@section('content')
<div>
    <h2>- カート -</h2>
    @if($user->carts()->exists())
    @foreach($user->carts as $cart)
    <form action="{{ route('user.product.piecies', $cart->product->id) }}">
        @if($cart->product->productImages->count())
            @foreach($cart->product->productImages as $productImage)
            <div>
                <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $productImage->product->product }}の画像{{ $loop->index + 1 }}">
            </div>
            @endforeach
        @else
            <p>画像はありません</p>
        @endif
        <p>商品名：{{ $cart->product->product }}</p>
        <p>値段：{{ $cart->product->price }}円</p>
        @foreach($cart->product->details as $detail)
            <p>サイズ：{{ $detail->size }}</p>
        @endforeach
        <label for="pieces">数量：</label>
        <select name="pieces{{ $loop->index + 1 }}" id="pieces">
            @for($piece = 1; $piece <= 10; $piece++)
                <option value="{{ $piece }}">{{ $piece }}</option>
            @endfor
        </select>
    </form>
    <form onsubmit="return confirm('カートから削除してよろしいですか？')" action="{{ route('user.product.uncart', $cart->product_id) }}" method="POST">
    @csrf
    @method('delete')
        <button type="submit">
            <img src="{{ asset('img/9CCB62AC-3D0D-4B7C-BC78-904AAAFFE52B.png') }}" alt="カートから削除の画像">
        </button>
    </form>
    <form action="{{ route('user.purchase.confirm', $cart->product->id) }}" method="get">
        <button type="submit">注文する</button>
    </form>
    @endforeach
        <p>合計金額：{{ $user->total_amount }}円</p>
        @else
            <p>カートにはまだ何も入っておりません。</p>
        @endif
</div>
@endsection
