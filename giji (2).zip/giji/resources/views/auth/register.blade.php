<form action="{{ route('register') }}" method="post">@csrf
  <label>名前
    <input type="name" name="name">
      @if($errors->has('name'))
        {{$errors->first('name')}}
      @endif
  </label>
  <label>メールアドレス
    <input type="email" name="email">
      @if($errors->has('password'))
        {{$errors->first('password')}}
      @endif
  </label>
  <label>パスワード
    <input type="password" name="password">
      @if($errors->has('password'))
        {{$errors->first('password')}}
      @endif
  </label>
  <label>パスワード確認
    <input type="password" name="password_confirmation">
      @if($errors->has('password_confirmation'))
        {{$errors->first('password_confirmation')}}
      @endif
  </label>
  <p>
    <a href="{{ route('login') }}">会員登録をされている方はログインへ</a>
  </p>
  <button type="submit">登録</button>
</form>
