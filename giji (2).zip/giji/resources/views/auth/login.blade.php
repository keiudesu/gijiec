<form action="{{ route('login') }}" method="post">@csrf
  <label>Email
    <input type="email" name="email">
    @if($errors->has('email'))
      {{ $errors->first('email') }}
    @endif
  </label>
  <label>パスワード</label>
    <input type="password" name="password">
      @if($errors->has('password'))
        {{ $errors->first('password') }}
      @endif
  </label>
  <p>
    <a href="{{ route('register') }}">新規ユーザーの方はこちら</a>
  </p>
  <button type="submit">ログイン</button>
</form>
