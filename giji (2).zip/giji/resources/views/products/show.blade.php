@extends('layouts.app')

@section('content')
    <div>
        @if($product->productImages()->exists())
            <div>
                <img src="{{ asset('images/' . $product->productImages->first()->image) }}" name="myBigImage">
            </div>
            <ul>
                @foreach($product->productImages as $productImage)
                    <li>
                        <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $product->product }}の画像{{ $loop->index + 1 }}">
                    </li>
                @endforeach
            </ul>
        @else
            <p>画像はありません</p>
        @endif
        <p>{{ $product->product }}</p>
        <p>{{ $product->price }}円</p>
    </div>
    <form action="{{ route('user.product.cart', $product->id) }}" method="post">@csrf
        <select name='detail'>
            <option>-detailを選択-</option>
                @foreach($product->details as $detail)
                        <option value="{{ $detail }}">{{ $detail->color }} {{ $detail->size }}</option>
                @endforeach
        </select>
        <p>{{ $product->favorites->count() }}人</p>
        <button type="submit">カートに入れる</button>
    </form>
    @if(Auth::user())
        @if(Auth::user()->favorites()->exists())
            <form action="{{ route('user.product.unfavorite', $product->id) }}" method="post">
                @method("delete")
                @csrf
                <button type="submit">
                    <img src="{{ asset('images/favorite.png') }}" alt="お気に入りボタンの画像">
                </button>
            </form>
        @else
            <form action="{{ route('user.product.favorite', $product->id) }}" method="post">
                @csrf
                <button type="submit">
                    <img src="{{ asset('images/favorite.png') }}" alt="お気に入りボタンの画像" class="favo-btn">
                </button>
            </form>
        @endif
    @else
        <form action="{{ route('user.product.favorite', $product->id) }}" method="post">
            @csrf
            <button type="submit">
                <img src="{{ asset('images/favorite.png') }}" alt="お気に入りボタンの画像" class="favo-btn">
            </button>
        </form>
    @endif
@endsection
