<header>
<div class="header">
    <div class="header-left">
      <div class="menu-trigger">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <ul class="humburger">
        @guest
          <li><a href="{{ route('login') }}">ログイン</a></li>
        @endguest
          <li><a href="{{ route('home') }}">Top</a></li>
          <li><a href="{{ route('user.scene.index') }}">シーン別コーデ</a></li>
          <li><a href="{{ route('user.cart.index') }}">カート</a></li>
          <li><a href="{{ route('user.product.favorites') }}">お気に入り</a></li>
          <li><a href="{{ route('user.profile') }}">マイページ</a></li>
          <li><a href="{{ route('user.purchased') }}">注文履歴</a></li>
        @auth
        <li>
          <form action="{{ route('logout') }}" method="POST" id="logout">
            @csrf
            <button type="submit" class="logout-btn">ログアウト</button>
          </form>
        </li>
        @endauth
      </ul>
      <div class="search">
        <img src="{{ asset('img/47EE5B58-65B0-40D8-AAB6-83BA1B731413.jpg') }}" class="search-img">
        <form action="search" method="POST">
          @csrf
          <input type="text" class="search-bar">
        </form>
      </div>
    </div>
    <div>
      <img src="{{ asset('img/IMG_0083.jpg') }}" class="header-title">
    </div>
    <div class="header-right">
      @auth
        <p class="header-username">{{ Auth::user()->name }}さん</p>
      @endauth
      @guest
        <p class="header-username">ゲストさん</p>
      @endguest
      <div class="header-mypage">
        <a href="{{ route('login') }}">
          <img src="{{ asset('img/658FDF52-6E8A-4C48-893E-8C54EE7A0778.png') }}" class="header-img">
        </a>
      </div>
      <div>
        <a href="{{ route('user.cart.index') }}">
          <img src="{{ asset('img/11BFBDB7-1F19-403E-95E5-18A17897AC1A.png') }}" class="header-img">
        </a>
      </div>
    </div>
  </div>
</header>
