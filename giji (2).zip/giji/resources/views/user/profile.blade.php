@extends('layouts.app')

@section('content')
<p>-マイページ-</p>
<p>Name</p>
<p>{{ $user->name }}</p>
<p>E-mail</p>
<p>{{ $user->email }}</p>
<p>Size</p>
<p>{{ $user->size }}</p>
<p>Shoes Size</p>
<p>{{ $user->shoes_size }}</p>
<button>
  <a href="{{ route('user.profile.edit') }}">アカウント情報変更</a>
</button>

@endsection
