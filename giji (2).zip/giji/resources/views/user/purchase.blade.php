@extends('layouts.app')

@section('content')
<p>Thank you</p>
<p>注文ありがとうございます</p>
<a href="{{ route('home') }}">TOPへ戻る</a>
@endsection
