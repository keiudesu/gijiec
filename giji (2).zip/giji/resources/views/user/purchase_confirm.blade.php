@extends('layouts.app')

@section('content')
<h2>-注文確認-</h2>
@if($product->productImages()->count())
<img src="{{ asset('images/' . $product->productImages->image) }}" alt="{{ $product->productImages->image }}の画像{{ $loop->index + 1 }}">
@else
<p>画像はありません</p>
@endif
<p>商品名：{{ $product->product }}</p>
<p>値段：{{ $product->price }}円</p>
@foreach( $product->details as $detail)
<p>サイズ：{{ $detail->size }}</p>
@endforeach
<form action="{{ route('user.purchase', $product->id) }}" method="post">@csrf
  <button type="submit">購入する</button>
</form>
<form action="{{ route('user.cart.index') }}" method="get">
  <button type="submit">カートに戻る</button>
</form>

@endsection
