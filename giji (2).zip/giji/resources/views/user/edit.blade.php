@extends('layouts.app')

@section('content')
<p>-アカウント情報変更-</p>
<form action="{{ route('user.profile.update', $user) }}" method="POST">
    @csrf
    @method('PUT')
    <label for="name">name</label>
    <input type="text" name="name" value="{{ $user->name }}">
    <label for="email">E-mail</label>
    <input type="email" name="email" value="{{ $user->email }}">
    <label for="size">Size</label>
    <select name="size">
      <option value="{{ $user->size }}" selected>{{ $user->size }}</option>
      <option value="S">S</option>
      <option value="M">M</option>
      <option value="L">L</option>
    </select>
    <label for="size">Shoes Size</label>
    <select name="shoes_size">
      <option value="{{ $user->shoes_size }}" selected>{{ $user->shoes_size }}</option>
      <option value="S">S</option>
      <option value="M">M</option>
      <option value="L">L</option>
    </select>
    <button type="submit">変更を確定する</button>
@endsection
