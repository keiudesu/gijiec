@extends('layouts.app')

@section('content')
<h1>-注文履歴-</h1>
    @if(Auth::user()->completes()->exists())
        @foreach(Auth::user()->completes as $complete)
            <p>購入日時:{{ $complete->created_at }}</p>
            @if($complete->product->productImages->count())
                @foreach($complete->product->productImages as $productImage)
                    <div>
                      <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $productImage->product->product }}の画像{{ $loop->index+1 }}">
                    </div>
                @endforeach
            @else
                <p>画像はありません</p>
            @endif
            <p>商品名:{{ $complete->product->product }}</p>
            <p>値段:{{ $complete->product->price }}円</p>
            <form action="{{ route('user.product.cart', $complete->product->id) }}" method="post">
            @csrf
                <button type="submit">再度購入</button>
            </form>
        @endforeach
    @else
        <p>まだ購入した商品はありません。</p>
    @endif
@endsection
