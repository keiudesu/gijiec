@extends('layouts.app')

@section('content')
@foreach($scene->outfits as $outfit)
<img src="{{ asset('images/' . $outfit->main_image) }}" alt="{{ $outfit->main_image }}の画像">
<form action="{{ route('user.product.cart', $outfit->product->id) }}" method="POST">@csrf
  <button type="submit">このコーデを買う</button>
</form>
@endforeach
@foreach($scene->outfits as $outfit)
@if($outfit->product->productImages->count())
  @foreach($outfit->product->productImages as $productImage)
    <img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $outfit->product->product }}の画像">
  @endforeach
@else
<p>画像はありません</p>
@endif
<p>{{ $outfit->product->product }}</p>
<p>{{ $outfit->product->price }}円</p>
@endforeach
@endsection
