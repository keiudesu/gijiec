@extends('layouts.app')

@section('content')
<h1>OUTFIT</h1>
<p>シーン別コーデ</p>

@foreach($scenes as $scene)
<a href="{{ route('user.scene.show', $scene->id) }}">
  <div><img src="{{ asset('images/' . $scene->image) }}" alt="{{ $scene->name }}の画像"></div>
</a>
@endforeach

@endsection
