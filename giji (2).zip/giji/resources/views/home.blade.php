@extends('layouts.app')

@section('content')
<h1>ITEM LIST</h1>
<h2>商品一覧</h2>
@foreach($products as $product)
<a href="{{ route('user.product.show', $product->id) }}">
  @if($product->productImages->count())
  @foreach($product->productImages as $productImage)
  <div><img src="{{ asset('images/' . $productImage->image) }}" alt="{{ $product->product }}の画像{{ $loop->index + 1 }}"></div>
  @endforeach
  @else
  <p>画像はありません</p>
  @endif
  <p>{{ $product->product }}</p>
  <p>{{ $product->price }}</p>
</a>
@endforeach
<a href="{{ route('user.product.index') }}">さらに表示</a>
<h1>RANKING</h1>
<h2>いま売れているアイテム</h2>
@foreach($productRankings as $productRanking)
<a href="{{ route('user.product.show', $product->id) }}">
  @if($productRanking->productImages->count())
  @foreach($productRanking->productImages as $productRankingImage)
  <ol>
    <li><img src="{{ asset('images/' . $productRankingImage->image) }}" alt="{{ $productRanking->product }}の画像{{ $loop->index + 1 }}"></li>
  </ol>
  @endforeach
  @else
  <p>画像はありません</p>
  @endif
  <p>{{ $productRanking->product }}</p>
  <p>{{ $productRanking->price }}</p>
</a>
@endforeach

@endsection
