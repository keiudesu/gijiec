<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
    <?php if($product->productImages->count()): ?>
    <div>
        <img class="big-image" src="<?php echo e(asset('images/' . $product->productImages->first()->image)); ?>" name="myBigImage">
    </div>
    <ul>
    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="show-images">
        <a href="javascript:void(0)" onmouseover="changeImg('<?php echo e(asset('images/' . $productImage->image)); ?>')"><img class="about-images" src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($product->product); ?>の画像<?php echo e($loop->index + 1); ?>"></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
    <p>画像はありません</p>
    <?php endif; ?>
    <p><?php echo e($product->product); ?></p>
    <p><?php echo e($product->price); ?>円</p>
</div>
<form action="products/cart/{product}" method="post"><?php echo csrf_field(); ?>
    <select name='color'>
        <option>-colorを選択-</option>
    <?php $__currentLoopData = $product->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($detail->color); ?>"><?php echo e($detail->color); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <select name='size'>
        <option>-sizeを選択-</option>
    <?php $__currentLoopData = $product->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($detail->size); ?>"><?php echo e($detail->size); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <p><?php echo e($product->favorites->count()); ?></p>
    <br>
    <button type="submit">カートに入れる</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/show.blade.php ENDPATH**/ ?>