<?php $__env->startSection('admin.content'); ?>
<div><a href="<?php echo e(route('admin.product.create')); ?>">商品を新規登録する</a></div>
<div><a href="<?php echo e(route('admin.scene.index')); ?>">シーン別コーデを登録・編集する</a></div>
<h1>登録済み商品一覧</h1>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($product->productImages->count()): ?>
  <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div><img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($product->product); ?>の画像<?php echo e($loop->index + 1); ?>"></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
  <p>画像はありません</p>
<?php endif; ?>
  <p><?php echo e($product->number); ?></p>
  <p><?php echo e($product->product); ?></p>
  <p><?php echo e($product->price); ?></p>
  <?php $__currentLoopData = $product->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p>サイズ：<?php echo e($detail->size); ?></p>
  <p>カラー：<?php echo e($detail->color); ?></p>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <button type="submit">
    <img src="<?php echo e(asset('img/9CCB62AC-3D0D-4B7C-BC78-904AAAFFE52B.png')); ?>" alt="商品削除の画像">
  </button>
  <div><a href="<?php echo e(route('admin.product.edit', $product->id)); ?>">商品情報を編集する</a></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div><a href="<?php echo e(route('admin.product.index')); ?>">さらに表示</a></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/admin/home.blade.php ENDPATH**/ ?>