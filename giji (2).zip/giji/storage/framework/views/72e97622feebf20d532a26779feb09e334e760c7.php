<?php $__env->startSection('content'); ?>
    <div>
        <?php if($product->productImages): ?>
            <div>
                <img src="<?php echo e(asset('images/' . $product->productImages->first()->image)); ?>" name="myBigImage">
            </div>
            <ul>
                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($product->product); ?>の画像<?php echo e($loop->index + 1); ?>">
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p>画像はありません</p>
        <?php endif; ?>
        <p><?php echo e($product->product); ?></p>
        <p><?php echo e($product->price); ?>円</p>
    </div>
    <form action="<?php echo e(route('user.product.cart', $product->id)); ?>" method="post"><?php echo csrf_field(); ?>
        <select name='detail'>
            <option>-detailを選択-</option>
                <?php $__currentLoopData = $product->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($detail); ?>"><?php echo e($detail->color); ?> <?php echo e($detail->size); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p><?php echo e($product->favorites->count()); ?>人</p>
        <form action="<?php echo e(route('user.product.favorite', $product->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit">
                <img src="<?php echo e(asset('images/favorite.png')); ?>" alt="お気に入りボタンの画像">
            </button>
        </form>
        <button type="submit">カートに入れる</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/products/show.blade.php ENDPATH**/ ?>