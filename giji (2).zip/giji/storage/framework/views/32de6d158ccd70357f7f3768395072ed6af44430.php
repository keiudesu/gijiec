<?php $__env->startSection('content'); ?>
<div>
    <h2>- カート -</h2>
    <?php if($user->carts()->exists()): ?>
    <?php $__currentLoopData = $user->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('user.product.piecies', $cart->product->id)); ?>">
        <?php if($cart->product->productImages->count()): ?>
            <?php $__currentLoopData = $cart->product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($productImage->product->product); ?>の画像<?php echo e($loop->index + 1); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>画像はありません</p>
        <?php endif; ?>
        <p>商品名：<?php echo e($cart->product->product); ?></p>
        <p>値段：<?php echo e($cart->product->price); ?>円</p>
        <?php $__currentLoopData = $cart->product->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>サイズ：<?php echo e($detail->size); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <label for="pieces">数量：</label>
        <select name="pieces<?php echo e($loop->index + 1); ?>" id="pieces">
            <?php for($piece = 1; $piece <= 10; $piece++): ?>
                <option value="<?php echo e($piece); ?>"><?php echo e($piece); ?></option>
            <?php endfor; ?>
        </select>
    </form>
    <form onsubmit="return confirm('カートから削除してよろしいですか？')" action="<?php echo e(route('user.product.uncart', $cart->product_id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
        <button type="submit">
            <img src="<?php echo e(asset('img/9CCB62AC-3D0D-4B7C-BC78-904AAAFFE52B.png')); ?>" alt="カートから削除の画像">
        </button>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p>合計金額：円</p>
        <button type="submit">注文内容を確認する</button>
        <?php else: ?>
            <p>カートにはまだ何も入っておりません。</p>
        <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/auth/cart.blade.php ENDPATH**/ ?>