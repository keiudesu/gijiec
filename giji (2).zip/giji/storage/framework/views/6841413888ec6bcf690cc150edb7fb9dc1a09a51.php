<header>
  <div class="header">
    <div class="header-left">
      <div class="menu-trigger">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <ul class="humburger">
          <li><a href="<?php echo e(route('admin.home')); ?>">Top</a></li>
          <?php if(auth()->guard()->check()): ?>
          <li>
            <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="logout-btn">ログアウト</button>
            </form>
          </li>
          <?php endif; ?>
      </ul>
      <div class="search">
        <img src="<?php echo e(asset('img/47EE5B58-65B0-40D8-AAB6-83BA1B731413.jpg')); ?>" class="search-img">
        <form action="search" method="POST">
          <?php echo csrf_field(); ?>
          <input type="text" class="search-bar">
        </form>
      </div>
    </div>
    <div>
      <img src="<?php echo e(asset('img/IMG_0083.jpg')); ?>" class="header-title">
    </div>
    <div class="header-right">
      <?php if(auth()->guard()->check()): ?>
        <p class="header-username"><?php echo e(Auth::user()->name); ?>さん</p>
      <?php endif; ?>
      <div class="header-mypage">
        <img src="<?php echo e(asset('img/658FDF52-6E8A-4C48-893E-8C54EE7A0778.png')); ?>" class="header-img">
      </div>
    </div>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\giji\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>