<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="utf-8">
  <title>アパレルEC_管理者</title>
  <meta name="description" content="">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
  <div id="app">
    <?php echo $__env->make('admin/layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
      <?php echo $__env->yieldContent('admin.content'); ?>
    </main>
    <?php echo $__env->make('admin/layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\giji\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>