<?php $__env->startSection('content'); ?>
<h1>-お気に入りリスト-</h1>
    <?php if($user->favorites()->exists()): ?>
    <?php $__currentLoopData = $user->favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($favorite->product->productImages->count()): ?>
            <?php $__currentLoopData = $favorite->product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                  <img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($productImage->product->product); ?>の画像<?php echo e($loop->index+1); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>画像はありません</p>
        <?php endif; ?>
        <p>商品名:<?php echo e($favorite->product->product); ?></p>
        <p>値段:<?php echo e($favorite->product->price); ?></p>
        <a href="">
            <button>
                <img src="<?php echo e(asset('images/delete')); ?>" alt="お気に入りから削除">
            </button>
        </a>
        <form action="<?php echo e(route('user.product.cart', $favorite->product->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
            <button type="submit">
                <img src="<?php echo e(asset('images/favorite.png')); ?>" alt="お気に入りボタンの画像">
            </button>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>まだお気に入りした商品はありません。</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/favorites/index.blade.php ENDPATH**/ ?>