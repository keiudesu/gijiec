<?php $__env->startSection('content'); ?>
<h1>-注文履歴-</h1>
    <?php if(Auth::user()->completes()->exists()): ?>
        <?php $__currentLoopData = Auth::user()->completes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>購入日時:<?php echo e($complete->created_at); ?></p>
            <?php if($complete->product->productImages->count()): ?>
                <?php $__currentLoopData = $complete->product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                      <img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($productImage->product->product); ?>の画像<?php echo e($loop->index+1); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>画像はありません</p>
            <?php endif; ?>
            <p>商品名:<?php echo e($complete->product->product); ?></p>
            <p>値段:<?php echo e($complete->product->price); ?>円</p>
            <form action="<?php echo e(route('user.product.cart', $complete->product->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
                <button type="submit">再度購入</button>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>まだお気に入りした商品はありません。</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/user/purchased.blade.php ENDPATH**/ ?>