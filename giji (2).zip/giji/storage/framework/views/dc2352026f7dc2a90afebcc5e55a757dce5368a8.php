<form action="<?php echo e(route('admin.login')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <label>Email
    <input type="email" name="email">
    <?php if($errors->has('email')): ?>
      <?php echo e($errors->first('email')); ?>

    <?php endif; ?>
  </label>
  <label>パスワード</label>
    <input type="password" name="password">
      <?php if($errors->has('password')): ?>
        <?php echo e($errors->first('password')); ?>

      <?php endif; ?>
  </label>
  <p>
    <a href="<?php echo e(route('admin.register')); ?>">新規ユーザーの方はこちら</a>
  </p>
  <button type="submit">ログイン</button>
</form>
<?php /**PATH C:\xampp\htdocs\giji\resources\views/auth/admin/login.blade.php ENDPATH**/ ?>