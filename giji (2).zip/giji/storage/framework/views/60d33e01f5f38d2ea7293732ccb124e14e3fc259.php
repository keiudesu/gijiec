<?php $__env->startSection('content'); ?>
<form action="register" method="POST">
  <?php echo csrf_field(); ?>
  <label for="name">Name</label>
  <input id="name" type="text" name="name">
  <br>
  <label for="email">email</label>
  <input id="email" type="email" name="email">
  <br>
  <label for="password">password</label>
  <input id="password" type="password" name="password">
  <br>
  <label for="password_confirmation">password-confirm</label>
  <input id="password_confirmation" type="password" name="password_confirmation">
  <br>
  <button type="submit">submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/auth/register.blade.php ENDPATH**/ ?>