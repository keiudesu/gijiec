<?php $__env->startSection('content'); ?>
<h1>ITEM LIST</h1>
<h2>商品一覧</h2>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('user.product.show', $product->id)); ?>">
  <?php if($product->productImages->count()): ?>
  <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div><img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($product->product); ?>の画像<?php echo e($loop->index + 1); ?>"></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <p>画像はありません</p>
  <?php endif; ?>
  <p><?php echo e($product->product); ?></p>
  <p><?php echo e($product->price); ?></p>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('user.product.index')); ?>">さらに表示</a>
<h1>RANKING</h1>
<h2>いま売れているアイテム</h2>
<?php $__currentLoopData = $productRankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productRanking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('user.product.show', $product->id)); ?>">
  <?php if($productRanking->productImages->count()): ?>
  <?php $__currentLoopData = $productRanking->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productRankingImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <ol>
    <li><img src="<?php echo e(asset('images/' . $productRankingImage->image)); ?>" alt="<?php echo e($productRanking->product); ?>の画像<?php echo e($loop->index + 1); ?>"></li>
  </ol>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <p>画像はありません</p>
  <?php endif; ?>
  <p><?php echo e($productRanking->product); ?></p>
  <p><?php echo e($productRanking->price); ?></p>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/home.blade.php ENDPATH**/ ?>