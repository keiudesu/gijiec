<?php $__env->startSection('admin.content'); ?>
<h1>ITEM LIST</h1>
<p>商品一覧画面</p>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>">
        <div>
            <?php if($product->productImages->count()): ?>
                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><img src="<?php echo e(asset('images/' . $productImage->image)); ?>" alt="<?php echo e($product->product); ?>の画像<?php echo e($loop->index + 1); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>画像はありません</p>
            <?php endif; ?>
            <h4><?php echo e($product->product); ?></h4>
            <p>¥<?php echo e($product->price); ?></p>
        </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giji\resources\views/admin/index.blade.php ENDPATH**/ ?>