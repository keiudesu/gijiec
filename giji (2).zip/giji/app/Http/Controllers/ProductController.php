<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Product;
use App\Complete;
use App\Cart;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function home()
    {
        $products = Product::take(3)->get();
        $today = Carbon::today();
        $complete_id = Complete::where('created_at', '>=', $today->subWeek())
            ->pluck('product_id');
        $productRankings = Product::withCount('completes')
            ->whereIn('id', $complete_id)
            ->orderBy('completes_count', 'desc')
            ->take(6)
            ->get();
        return view('home', compact('products', 'productRankings'));
    }
    public function show($id)
    {
        $product = Product::where('id', $id)->first();
        return view('products.show', compact('product'));
    }
    public function index()
    {
        $products = Product::orderBy('products.created_at', 'desc')->paginate(6);

        return view('index',['products' => $products]);
    }
    public function cart($id)
    {
        $cart = new Cart;
        $cart->product_id = $id;
        $cart->user_id = Auth::id();
        $cart->save();
        return redirect()->route('user.cart.index');
    }
    public function uncart($id)
    {
        Cart::where('user_id',Auth::id())
            ->where('product_id',$id)
            ->delete();
        return redirect()->route('user.cart.index');
    }

    public function adminHome()
    {
        $products = Product::orderBy('products.created_at', 'desc')->take(5)->get();
        return view('admin.home', compact('products'));
    }
    public function adminIndex(){
        $products = Product::orderBy('products.created_at', 'desc')->paginate(6);
        return view('admin.index', compact('products'));
    }
    public function purchaseConfirm(Product $product)
    {

        return view('user.purchase_confirm', compact('product'));
    }
    public function purchase(Int $id)
    {
        $complete = new Complete;
        $complete->product_id = $id;
        $complete->user_id = Auth::id();
        $complete->save();
        return view('user.purchase');
    }

    public function adminSearch(Request $request)
    {
        $keyword = $request->input('admin_search');
        $products = Product::where('product', 'like', "%{$keyword}%")->where('admin_id', Auth::id())->get();
        return view('admin.search', compact('products', 'keyword'));
    }
}
