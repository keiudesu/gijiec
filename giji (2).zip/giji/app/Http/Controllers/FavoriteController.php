<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;

class FavoriteController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        return view('favorites.index', compact('user'));
    }

    public function favorite($product)
    {
        Auth::user()->favorite($product);
        return back();
    }

    public function unfavorite($product)
    {
        Auth::user()->unfavorite($product);
        return back();
    }
}
