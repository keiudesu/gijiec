<?php

namespace App\Http\Controllers;

use App\Scene;

class SceneController extends Controller
{
    public function index()
    {
        $scenes = Scene::all();

        return view('scenes.index', ['scenes' => $scenes]);
    }

    public function show($id)
    {
        $scene = Scene::find($id);

        return view('scenes.show', compact('scene'));
    }
}
