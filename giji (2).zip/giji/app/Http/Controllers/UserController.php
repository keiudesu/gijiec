<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function cartIndex()
    {
        $user = Auth::user();
        return view('auth.cart', compact('user'));
    }

    public function profile()
    {
        $user = Auth::user();
        return view('user.profile', compact('user'));
    }

    public function purchased()
    {
        return view('user.purchased');
    }

    public function edit()
    {
        $user = Auth::user();
        return view('user.edit', compact('user'));
    }

    public function update(Request $request)
    {
        Auth::user()->fill($request->all())->save();
        return redirect()->route('user.profile');
    }
}
