<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scene extends Model
{
    public function outfits(){
        return $this->hasMany('App\Outfit');
    }

    public function admin(){
        return $this->belongsTo('App\Admin');
    }
}
