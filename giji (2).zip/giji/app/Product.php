<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public function carts(){
        return $this->hasMany('App\Cart');
    }

    public function completes(){
        return $this->hasMany('App\Complete');
    }

    public function details(){
        return $this->hasMany('App\Detail');
    }

    public function favorites(){
        return $this->hasMany('App\Favorite');
    }

    public function outfits(){
        return $this->hasMany('App\Outfit');
    }

    public function productImages(){
        return $this->hasMany('App\ProductImage');
    }

    public function admin(){
        return $this->belongsTo('App\Admin');
    }
}
