<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'size', 'shoes_size', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function carts(){
        return $this->hasMany('App\Cart');
    }

    public function completes(){
        return $this->hasMany('App\Complete')->orderBy('created_at', 'desc');
    }

    public function favorites(){
        return $this->belongsToMany('App\Product', 'favorites', 'user_id', 'product_id');
    }

    public function isFavorite($product){
        return $this->favorites()->where('product_id', $product)->exists();
    }

    public function favorite($product){
        if($this->isFavorite($product)){
        } else {
            $this->favorites()->attach($product);
        }
    }

    public function unfavorite($product){
        if($this->isFavorite($product)){
            $this->favorites()->detach($product);
        } else {
        }
    }

    public function getTotalAmountAttribute(){
        $total = 0;
        foreach($this->carts as $cart){
            $total += $cart->product->price;
        }
        return $total;
    }
}
