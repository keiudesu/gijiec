<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Outfit;
use App\Scene;
use App\Product;
use Faker\Generator as Faker;

$factory->define(Outfit::class, function (Faker $faker) {
    return [
        'scene_id' => $faker->numberBetween(1, 3),
        'product_id' => factory(Product::class),
        'name' => 'example',
        'main_image' => 'exampleimage.png',
    ];
});
