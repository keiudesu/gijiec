<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Detail;
use App\Product;
use Faker\Generator as Faker;

$factory->define(Detail::class, function (Faker $faker) {
    return [
        'product_id' => factory(Product::class),
        'size' => 'S',
        'color' => 'ブラック',
    ];
});

$factory->state(Detail::class, '0', [
        'size' => 'S',
        'color' => 'ブラック',
]);
$factory->state(Detail::class, '1', [
        'size' => 'M',
        'color' => 'ホワイト',
]);
$factory->state(Detail::class, '2', [
        'size' => 'L',
        'color' => 'レッド',
]);
$factory->state(Detail::class, '3', [
        'size' => 'S',
        'color' => 'イエロー',
]);
$factory->state(Detail::class, '4', [
        'size' => 'M',
        'color' => 'ブルー',
]);
