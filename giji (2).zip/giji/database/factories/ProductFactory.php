<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Product;
use App\Admin;
use Faker\Generator as Faker;

$factory->define(Product::class, function (Faker $faker) {
    return [
        'admin_id' => factory(Admin::class),
        'number' => $faker->unique()->isbn13,
        'product' => 'ロゴ入りTシャツ',
        'price' => 1000,
        'category' => 'トップス',
        'subcategory' => 'Tシャツ',
    ];
});

$factory->state(Product::class, '0', [
        'product' => 'ロゴ入りTシャツ',
        'price' => 1000,
        'category' => 'トップス',
        'subcategory' => 'Tシャツ',
]);
$factory->state(Product::class, '1', [
        'product' => 'シャツワンピース',
        'price' => 5000,
        'category' => 'ワンピース',
        'subcategory' => 'ワンピース',
]);
$factory->state(Product::class, '2', [
        'product' => 'ストレッチジャケット',
        'price' => 6000,
        'category' => 'アウター',
        'subcategory' => 'ジャケット',
]);
$factory->state(Product::class, '3', [
        'product' => 'イージーパンツ',
        'price' => 4000,
        'category' => 'ボトムス',
        'subcategory' => 'パンツ',
]);
$factory->state(Product::class, '4', [
        'product' => 'ショルダートートバッグ',
        'price' => 1500,
        'category' => 'バッグ',
        'subcategory' => 'トートバッグ',
]);
$factory->state(Product::class, '5', [
        'product' => 'キャンバススニーカー',
        'price' => 3000,
        'category' => 'シューズ',
        'subcategory' => 'スニーカー',
]);
$factory->state(Product::class, '6', [
        'product' => 'レザーベルト',
        'price' => 2500,
        'category' => 'アクセサリー',
        'subcategory' => 'ベルト',
]);
