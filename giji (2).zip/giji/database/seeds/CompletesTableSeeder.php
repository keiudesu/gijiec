<?php

use App\Complete;
use Illuminate\Database\Seeder;

class CompletesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $completes = factory(Complete::class,10)->create();
    }
}
