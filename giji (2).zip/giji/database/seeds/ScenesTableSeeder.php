<?php

use App\Scene;
use Illuminate\Database\Seeder;

class ScenesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Scene::create([
            'admin_id' => '1',
            'name' => 'Sports',
            'image' => 'sports.png',
        ]);

        Scene::create([
            'admin_id' => '2',
            'name' => 'Dating',
            'image' => 'dating.png',
        ]);

        Scene::create([
            'admin_id' => '3',
            'name' => 'Relaxing',
            'image' => 'relaxing.png',
        ]);
    }
}
