<?php

use App\Outfit;
use Illuminate\Database\Seeder;

class OutfitsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $outfits = factory(Outfit::class,10)->create();
    }
}
