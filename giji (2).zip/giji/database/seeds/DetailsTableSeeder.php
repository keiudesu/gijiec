<?php

use App\Detail;
use Illuminate\Database\Seeder;

class DetailsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $details = factory(Detail::class,2)->states('0')->create();
        $details = factory(Detail::class,2)->states('1')->create();
        $details = factory(Detail::class,2)->states('2')->create();
        $details = factory(Detail::class,2)->states('3')->create();
        $details = factory(Detail::class,2)->states('4')->create();
    }
}
