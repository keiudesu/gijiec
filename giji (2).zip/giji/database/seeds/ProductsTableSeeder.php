<?php

use App\Product;
use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $products = factory(Product::class,2)->states('0')->create();
        $products = factory(Product::class,2)->states('1')->create();
        $products = factory(Product::class,2)->states('2')->create();
        $products = factory(Product::class,1)->states('3')->create();
        $products = factory(Product::class,1)->states('4')->create();
        $products = factory(Product::class,1)->states('5')->create();
        $products = factory(Product::class,1)->states('6')->create();
    }
}
