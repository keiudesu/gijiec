<?php

use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'ユーザーテスト',
            'email' => 'test@gmail.com',
            'password' => Hash::make('testtest'),
            'size' => 'S',
            'shoes_size' => 'L',
        ]);
        $users = factory(User::class, 3)->states('0')->create();
        $users = factory(User::class, 3)->states('1')->create();
        $users = factory(User::class, 3)->states('2')->create();
    }
}
