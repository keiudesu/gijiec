'use strict';

// humburger menu
$(function(){
    $('.menu-trigger').on('click', function(){
        $(this).toggleClass('active');
        if($(this).hasClass('active')){
            $('.humburger').addClass('active');
        } else {
            $('.humburger').removeClass('active');
        }
    });
})

// search bar
$(function(){
    $('.search-img').on('click', function(){
        $(this).toggleClass('active');
        if($(this).hasClass('active')){
            $('.search-img').addClass('active');
            $('.search-bar').addClass('active');
        } else {
            $('.search-img').removeClass('active');
            $('.search-bar').removeClass('active');
        }
    });
});
$(document).on('click', function(event) {
    if(!$(event.target).closest('.search').length) {
        $('.search-img').removeClass('active');
        $('.search-bar').removeClass('active');
    }
});
